/**
* @file cmatrix.c
* @brief 用c语言实现矩阵运算
*
* @author 讨论组
* @date  20141203
* @version 1.0
*/

#include<stdio.h>
#include <math.h>
#include <malloc.h>
#include "cmatrix.h"

/**
 * @brief initial
 * @param T 矩阵
 * @param m 行数
 * @param n 列数
 */
void initial(matrix *T, int m, int n)
{
    T->mat = (double*)malloc(m*n*sizeof(double));
    T->m = m;
    T->n = n;
}


/**
 * @brief initZero
 * @param T 矩阵
 * @param m 行数
 * @param n 列数
 */
void initZero(matrix *T,int m,int n)
{
    int i;
    initial(T, m, n);
    for(i = 0; i < m*n; i++)
    {
        T->mat[i] = 0;
    }
}


/**
 * @brief destroy
 * @param T 矩阵
 */
void destroy(matrix *T)
{
    free(T->mat);
}

/**
 * @brief set
 * @param T 矩阵
 */
void set(matrix *T)
{    	
    int i,m,n;
    printf("请输入矩阵的行数和列数:\n");
    scanf("%d %d", &m, &n);
    initial(T, m, n);
    printf("输入矩阵的元素:\n");
    for(i = 0; i < m*n; i++)
    {
        scanf("%lf", &T->mat[i]);
    }
} 

/**
 * @brief show
 * @param T 矩阵
 */
void show(matrix *T)
{
    int i,j;
    int m = T->m;
    int n = T->n;
    for(i = 0; i < m; i++)
    {
        for(j = 0; j < n; j++)
        {
            printf("%lf  ", T->mat[n*i+j]);
        }
        printf("\n");
    }
}

/**
 * @brief unit
 * @param T 矩阵
 * @param m 行列数
 */
void unit(matrix *T,int m)
{
    int i,j;/* 定义变量i,j*/
    initial(T,m,m);/* 为矩阵分配存储空间*/
    for(i = 0; i < m; i++)
    {
        for(j = 0; j < m; j++)
        {
            if(i == j)/* 判断是否i=j*/
                T->mat[m*i+j] = 1;/* 若是,将第m*i+j个元素赋值为1 */
            else
                T->mat[m*i+j] = 0;/* 反之,将第m*i+j个元素赋值为0 */
        }
    }
}

/**
 * @brief scalar_multiply
 * @param  A 矩阵
 * @param  B 矩阵
 * @param  s 任意值
 */
void scalar_multiply(matrix *A, double s, matrix *B)
{
    int m = A->m;
    int n = A->n;

    initial(B,m,n);

    int i;
    for(i = 0; i < m*n; i++)
    {
        B->mat[i] = s*A->mat[i];
    }
}

/**
 * @brief 判断矩阵是否同型
 * @param  A 矩阵
 * @param  B 矩阵
 * @return 0或1
 */
int is_homotype(matrix *A, matrix *B)
{
    if(A->m == B->m && A->n == B->n)
        return 1;
    else
        return 0;
}

/**
 * @brief 矩阵相加
 * @param  A 矩阵
 * @param  B 矩阵
 * @param  T 矩阵
 * @return  0或1
 */
int add(matrix *A, matrix *B, matrix *T)
{
    if(!is_homotype(A,B))
    {
        printf("两个矩阵不能相加\n");
        return 0;
    }
    
    int i;
    int m = A->m;
    int n = A->n;
    initial(T, m, n);
    for(i = 0; i < m*n; i++)
    {
        T->mat[i] = A->mat[i] + B->mat[i];
    }

    return 1;
}



/**
 * @brief 矩阵相减
 * @param  A 矩阵
 * @param  B 矩阵
 * @param  T 矩阵
 * @return  0或1
 */
int subtract(matrix *A,matrix *B,matrix* T)
{
    if(!is_homotype(A,B))
    {
        printf("两个矩阵不能相减\n");
        return 0;
    }
    
    int i;
    int m = A->m;
    int n = A->n;
    initial(T, m, n);
    for(i = 0; i < T->m*T->n; i++)
    {
        T->mat[i] = A->mat[i] - B->mat[i];
    }
    return 1;
}

/**
 * @brief 判断矩阵是否可相乘
 * @param  A 矩阵
 * @param  B 矩阵
 * @return 0或1
 */
int is_multipliable(matrix *A,matrix *B)
{
    if(A->n == B->m)
        return 1;
    else
        return 0;
}

/**
 * @brief 矩阵相乘
 * @param  A 矩阵
 * @param  B 矩阵
 * @param  T 矩阵
 * @return  0或1
 */
int multiply(matrix *A,matrix *B,matrix* T)
{	
    if(!is_multipliable(A,B))
    {
        printf("两个矩阵不能相乘\n");
        return 0;
    }
    
    int i,j,k;
    int m = A->m;
    int l = A->n;
    int n = B->n;
    initZero(T, m, n);

    for(i = 0; i < m; i++)
    {
        for(j = 0; j < n; j++)
        {
            for(k = 0; k < l; k++)
            {
                T->mat[i*n+j] += A->mat[i*l+k]*B->mat[k*n+j];
            }
        }
    }
    return 1;
}


/**
 * @brief 判断是否为方阵
 * @param  T 方阵
 * @return  0或1
 */
int is_square(matrix *T)
{
    if(T->n == T->m)
        return 1;
    else
        return 0;
}

/**
 * @brief 求元素mat[x][y](x,y从0开始)的余子式
 * @param T 矩阵
 * @param x 行标
 * @param y 列标
 * @param leftmatrix 矩阵
 * @return
 */
int left(matrix* T,int x, int y, matrix* leftmatrix)
{
    int m = T->m - 1;
    int n = T->n - 1;
    if(m == 0 || n == 0 || (x >= m+1 )||(y >= n+1 ))
    {
        printf("余子式不存在");
        return 0;
    }
    initial(leftmatrix,m,n);
    int i,j;
    for(i = 0; i < m; i++)
    {
        for(j = 0; j < n; j++)
        {

            if(i < x && j < y)
            {
                leftmatrix->mat[i*n+j] = T->mat[i*(n+1)+j];
            }
            else if(i >= x && j < y)
            {
                leftmatrix->mat[i*n+j] = T->mat[(i+1)*(n+1)+j];
            }
            else if(i < x && j >= y)
            {
                leftmatrix->mat[i*n+j] = T->mat[i*(n+1)+(j+1)];
            }
            else
            {
                leftmatrix->mat[i*n+j] = T->mat[(i+1)*(n+1)+(j+1)];
            }

        }
    }

    return 1;
}

/**
 * @brief 求方阵的行列式
 * @param T 矩阵
 * @return  0或1
 */
double det(matrix* T)
{
    if(!is_square(T))
    {
        printf("不是方阵!");
        return 9.99;
    }

    int m = T->m;
    if(m == 0)
    {
        return 0;
    }
    else if(m == 1)
    {
        return T->mat[0];
    }
    else if(m == 2)
    {
        return (T->mat[0]*T->mat[3] - T->mat[1]*T->mat[2]);
    }
    else
    {
        double sum = 0;
        int i,a = 1;
        matrix L;
        for(i = 0; i < m; i++)
        {
            left(T,0,i,&L);/* 申请空间并赋值 */
            sum = sum + a*T->mat[i]*det(&L);/* 按第0行展开*/
            destroy(&L);/* 释放空间*/

            a = -a;
        }
        return sum;
    }
}

/**
 * @brief is_singular
 * @param T 方阵
 * @return 0或1
 */
int is_singular(matrix *T)
{
    if(det(T) == 0)
        return 1;
    else
        return 0;
}

/**
 * @brief adjoint
 * @param A 方阵
 * @param T A的伴随矩阵
 * @return 0或1
 */
int adjoint(matrix* A,matrix* T)
{
    if( (!is_square(A)) || is_singular(A) || A->m == 1 )
    {
        printf("无法计算伴随矩阵");
        return 0;
    }
    int m = A->m;
    int n = A->n;
    initial(T,m,n);

    matrix L;
    int i,j,a = 1;
    for(i = 0; i < m; i++)
    {
        for(j = 0; j < n; j++)
        {
            left(A,i,j,&L);/* 申请空间并赋值 */
            T->mat[i*n + j] = a*det(&L);
            destroy(&L);/* 释放空间*/
            a = -a;
        }
        a = -a;
    }
    return 1;
}

/**
 * @brief inverse
 * @param A 方阵
 * @param T A的逆矩阵
 * @return 0或1
 */
int inverse(matrix *A, matrix *T)
{
    int m = A->m;
    int n = A->n;
    initial(T,m,n);


    double s = det(A);
    matrix L;
    int i,j,a = 1;
    for(i = 0; i < m; i++)
    {
        for(j = 0; j < n; j++)
        {
            left(A,i,j,&L);/* 申请空间并赋值 */
            T->mat[i*n + j] = a*det(&L)/s;
            destroy(&L);/* 释放空间*/
            a = -a;
        }
        a = -a;
    }
    return 1;
}

/**
 * @brief transpose
 * @param A 矩阵
 * @param T A的转置矩阵
 * @return 0或1
 */
int transpose(matrix * A, matrix * T)
{
    int m = A->m;
    int n = A->n;
    initial(T,n,m);
    int i,j;
    for(i = 0; i < m; i++)
        for(j = 0; j < n; j++)
        {
            T->mat[j*m + i] = A->mat[i*n + j];
        }
    return 1;
}

/**
 * @brief is_symmetric
 * @param T 方阵
 * @return 0或1
 */
int is_symmetric(matrix *T)
{
    if(!is_square(T))
        return 0;

    int m = T->m;
    int n = T->n;

    if(m == 1)
        return 1;

    int i,j;
    for(i = 0; i < m; i++)
        for(j = i+1; j < n; j++)
        {
            if(T->mat[j*m + i] != T->mat[i*n + j])
                return 0;
        }
    return 1;
}

/**
 * @brief is_dissymmetric
 * @param T 矩阵
 * @return 0或1
 */
int is_dissymmetric(matrix *T)
{
    if(!is_square(T))
        return 0;
    int m = T->m;
    int n = T->n;
    if(m == 1&&T->mat[0]==0)
        return 1;  //也满足反对称矩阵条件
    int i,j;
    for(i=0;i<m;i++)
    {
        for(j=i;j<n;j++)
        {
            if(T->mat[j*m+i]!=(-T->mat[i*n+j]))
                return 0;

        }
    }
    return 1;
}

/**
 * @brief 互换第i行(列)和第j行(列)
 * @param T 矩阵
 * @param i 行或列数
 * @param j 行或列数
 * @param flag ROW或COLUMN 表示行变换或列变换
 * @return 0或1
 */
int primary_transform_1(matrix *T, int i, int j, Orientation flag)
{

    int m = T->m;
    int n = T->n;
    if(m == 0 || n == 0)
    {
        printf("矩阵未初始化");
        return 0;
    }

    int k;
    double temp;
    if(flag == ROW)
    {
        if( (i >= m )||(j >= m ))
        {
            printf("输入的行标过界");
            return 0;
        }

        //换行
        for(k = 0; k < n; k++)
        {
            temp = T->mat[i*n + k];
            T->mat[i*n + k] = T->mat[j*n + k];
            T->mat[j*n + k] = temp;
        }
    }
    else if(flag == COLUMN)
    {
        if( (i >= n )||(j >= n ))
        {
            printf("输入的列标过界");
            return 0;
        }

        //换列
        for(k = 0; k < m; k++)
        {
            temp = T->mat[k*n + i];
            T->mat[k*n + i] = T->mat[k*n + j];
            T->mat[k*n + j] = temp;
        }
    }
    else
    {
        printf("最后一个参数只能输入ROW或COLUMN");
        return 0;
    }

    return 1;


}

/**
 * @brief 以不为0的数s乘第i行(列)的所有元素
 * @param T 矩阵
 * @param i 行或列数
 * @param s 任意数
 * @param flag ROW或COLUMN 表示行变换或列变换
 * @return 0或1
 */
int primary_transform_2(matrix *T, int i, double s, Orientation flag)
{
    if(s == 0)
    {
        printf("数s不能为0");
        return 0;
    }

    int m = T->m;
    int n = T->n;
    if(m == 0 || n == 0)
    {
        printf("矩阵未初始化");
        return 0;
    }

    int k;
    if(flag == ROW) //行变换
    {
        if( i >= m )
        {
            printf("输入的行标过界");
            return 0;
        }

        for(k = 0; k < n; k++)
        {
            T->mat[i*n + k] = s*T->mat[i*n + k];
        }
    }
    else if(flag == COLUMN)
    {
        if( i >= n )
        {
            printf("输入的列标过界");
            return 0;
        }

        for(k = 0; k < m; k++)
        {
            T->mat[k*n + i] = s*T->mat[k*n + i];
        }

    }
    else
    {
        printf("最后一个参数只能输入ROW或COLUMN");
        return 0;
    }
    return 1;
}

/**
 * @brief 将第j行(列)的各个元素乘s加到第i行(列)的对应元素上
 * @param T 矩阵
 * @param i 行或列数
 * @param j 行或列数
 * @param s 任意数
 * @param flag ROW或COLUMN 表示行变换或列变换
 * @return 0或1
 */
int primary_transform_3(matrix *T, int i, int j, double s, Orientation flag)
{
    if(s == 0)
    {
        printf("数s不能为0");
        return 0;
    }

    int m = T->m;
    int n = T->n;
    if(m == 0 || n == 0)
    {
        printf("矩阵未初始化");
        return 0;
    }

    int k;
    if(flag == ROW) //行变换
    {
        if( (i >= m )||(j >= m ))
        {
            printf("输入的行标过界");
            return 0;
        }

        for(k = 0; k < n; k++)
        {
            T->mat[i*n + k] += s*T->mat[j*n + k];
        }
    }
    else if(flag == COLUMN)
    {
        if( (i >= n )||(j >= n ))
        {
            printf("输入的列标过界");
            return 0;
        }

        for(k = 0; k < m; k++)
        {
            T->mat[k*n + i] += s*T->mat[k*n + j];
        }

    }
    else
    {
        printf("最后一个参数只能输入ROW或COLUMN");
        return 0;
    }

    return 1;
}

/**
 * @brief one_norm
 * @param T 矩阵
 * @return 1范数
 */
double one_norm(matrix *T)
{
    double sum, norm = 0;
    int m = T->m;
    int n = T->n;

    int i,j;
    for(i = 0; i < n; i++)
    {
        sum = 0;
        for(j = 0; j < m; j++)
        {
            sum += fabs(T->mat[j*n + i]);
        }
        norm = (norm > sum) ? norm : sum;
    }
    return norm;
}

/**
 * @brief infinite_norm
 * @param T 矩阵
 * @return 无穷范数
 */
double infinite_norm(matrix *T)
{
    double sum, norm = 0;
    int m = T->m;
    int n = T->n;

    int i,j;
    for(i = 0; i < m; i++)
    {
        sum = 0;
        for(j = 0; j < n; j++)
        {
            sum += fabs(T->mat[i*n + j]);
        }
        norm = (norm > sum) ? norm : sum;
    }
    return norm;
}

/**
 * @brief f_norm
 * @param T 矩阵
 * @return F范数
 */
double f_norm(matrix *T)
{
    double sum, norm = 0;
    int m = T->m;
    int n = T->n;

    int i;
    for(i = 0; i < m*n; i++)
    {
        sum += T->mat[i]*T->mat[i];
    }
    norm = sqrt(sum);
    return norm;
}
