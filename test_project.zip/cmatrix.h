/**
* @file cmatrix.h
* @brief 用c语言编写矩阵运算
*
* @author 讨论组
* @date  20141203
* @version 1.0
* @todo 完成矩阵的以下操作:
* 零矩阵 单位矩阵 负矩阵
* 矩阵的加法，数乘，乘法
* 转置矩阵 
* 行列式 判断矩阵是否奇异 伴随矩阵 逆矩阵
* 判断矩阵是否对称矩阵 判断矩阵是否反对称矩阵
* 分块矩阵
* 矩阵的三种初等变换:(1）lambda*r_i (2)r_i <-> r_j (3) r_i + lambda*r_j
* 矩阵的范数-1，无穷，F范数
* 求特征值，2范数 对应的对角矩阵
*/


#ifndef CMATRIX_H
#define CMATRIX_H

/**  使用结构体,定义矩阵 */
typedef struct
{
    double *mat; /**< 等价于一维数组，长度为m*n */
    int m;/**< m 行数 */
    int n; /**< n 列数*/
}matrix;

typedef enum {ROW = 0,COLUMN = 1}Orientation;

/** 为矩阵申请存储空间 */
void initial(matrix *T,int m,int n);

/** 初始化矩阵 */
void initZero(matrix *T,int m,int n);

/** 创建单位矩阵*/
void unit(matrix *T,int m);

/** 释放空间*/
void destroy(matrix *T);



/** 对矩阵赋值 */
void set(matrix *T);

/** 在屏幕上显示矩阵*/
void show(matrix *T);


/** 数乘　*/
void scalar_multiply(matrix *, double, matrix *);


/** 判断矩阵是否同型*/
int is_homotype(matrix *,matrix *);

/** 矩阵相加*/
int add(matrix *,matrix *,matrix *);

/** 矩阵相减*/
int subtract(matrix *,matrix *,matrix *);



/** 判断矩阵是否可相乘*/
int is_multipliable(matrix *,matrix *);

/** 矩阵相乘*/
int multiply(matrix *,matrix *,matrix*);




/** 判断是否为方阵*/
int is_square(matrix *);

/** 求元素mat[x][y](x,y从0开始)的余子式*/
int left(matrix *, int, int, matrix *);

/**  求方阵的行列式*/
double det(matrix *);



/** 判断奇异性 */
int is_singular(matrix *);

/** 伴随矩阵*/
int adjoint(matrix *, matrix *);

/** 逆矩阵*/
int inverse(matrix *, matrix *);



/** 转置矩阵 */
int transpose(matrix *, matrix *);

/** 对称矩阵*/
int is_symmetric(matrix *);

/** 反对称对称矩阵*/
int is_dissymmetric(matrix *);



/** 第一初等变化*/
int primary_transform_1(matrix *, int, int, Orientation);

/** 第二初等变化*/
int primary_transform_2(matrix *, int, double, Orientation);

/** 第三初等变化*/
int primary_transform_3(matrix *, int, int, double, Orientation);



/** 1范数 */
double one_norm(matrix *);

/** 无穷范数*/
double infinite_norm(matrix *);

/** F范数*/
double f_norm(matrix *);

#endif
