/**
* @file matrix.cpp
* @brief 对类中成员及友元函数的实现
*
* @author 讨论组
* @date  20141127
* @version 1.0
*/

# include <iostream>
# include "matrix.h"

using namespace std;

Matrix::Matrix()
{
    m = 8;
    n = 8;
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
            arr[i][j] = 0;
    }
}

Matrix::Matrix(double x)
{
    m = 1;
    n = 1;
    arr[0][0] = x;
}

/**
 * @brief Matrix::set  对矩阵赋值
*/
void Matrix::set()
{
    cout<<"Set the type of the ?x? Matrix"<<endl;
    cin>>m>>n;
    cout<<"Now input the elements of the Matrix:"<<endl;
    for(int i=0;i<m;i++)
    {
        for(int j=0;j<n;j++)
            cin>>arr[i][j];
    }
}

/**
 * @brief Matrix::show 在屏幕上显示矩阵
 */
void Matrix::show()
{
    cout<<"This is the Matrix:"<<endl;
    for(int i=0;i < m;i++)
    {
        for(int j=0;j<n;j++)
        {
            cout<<arr[i][j]<<" ";
        }
        cout<<endl;
    }
}

/**
 * @brief homotype 判断矩阵x和矩阵y是否同型
 * @param x 矩阵
 * @param y 矩阵
 * @return 0或1
 */
int homotype(Matrix & x,Matrix &y)
{
    if(x.m==y.m &&x.n==y.n)
        return 1;
    else
        return 0;
}

/**
 * @brief multipliable 判断矩阵是否可相乘
 * @param x 矩阵
 * @param y 矩阵
 * @return 0或1
 */
int multipliable(Matrix &x,Matrix &y)
{
    if(x.n==y.m)
        return 1;
    else
        return 0;
}

/**
 * @brief add 矩阵相加
 * @param x 矩阵
 * @param y 矩阵
 * @return 矩阵
 */
Matrix add(Matrix &x,Matrix &y)
{
    Matrix z;
    if(homotype(x,y))
    {
        z.m = x.m;
        z.n = x.n;
        for(int i=0;i<z.m;i++)
            for(int j=0;j<z.n;j++)
                z.arr[i][j] = x.arr[i][j] + y.arr[i][j];
        return z;
    }
    else
    {
        cout<<"cannot be added!"<<endl;
        return z;
    }
}

/**
 * @brief operator + 矩阵相加,对加号重载
 * @param x 矩阵
 * @param y 矩阵
 * @return 矩阵
 */
Matrix operator +(Matrix &x,Matrix &y)
{
    return add(x,y);
}

/**
 * @brief subtract  矩阵相减
 * @param x 矩阵
 * @param y 矩阵
 * @return 矩阵
 */
Matrix subtract(Matrix &x,Matrix &y)
{
    Matrix z;
    if(homotype(x,y))
    {
        z.m = x.m;
        z.n = x.n;
        for(int i=0;i<z.m;i++)
            for(int j=0;j<z.n;j++)
                z.arr[i][j] = x.arr[i][j] - y.arr[i][j];
        return z;
    }
    else
    {
        cout<<"cannot be subtracted!"<<endl;
        return z;
    }
}

/**
 * @brief operator -  矩阵相减,对减号重载
 * @param x 矩阵
 * @param y 矩阵
 * @return 矩阵
 */
Matrix operator -(Matrix &x,Matrix &y)
{
    return subtract(x,y);
}

/**
 * @brief multiply 矩阵相乘
 * @param x 矩阵
 * @param y 矩阵
 * @return 矩阵
 */
Matrix multiply(Matrix &x,Matrix &y)
{
    Matrix z;
    if(x.n!=y.m)
    {
        cout<<"The two Matrixes cannot be multiplied."<<endl;
        return z;
    }
    for(int i=0;i<x.m;i++)
    {
        for(int j=0;j<y.n;j++)
        {
            for(int k=0;k<x.n;k++)
                z.arr[i][j] += x.arr[i][k]*y.arr[k][j];
        }
    }
    z.m = x.m;
    z.n = y.n;
    return z;
}

/**
 * @brief operator *  矩阵相乘,对乘号重载
 * @param x 矩阵
 * @param y 矩阵
 * @return 矩阵
 */
Matrix operator *(Matrix &x,Matrix &y)
{    
    return multiply(x,y);
}

/**
 * @brief Matrix::issquare 判断是否为方阵;
 * @return 0或1
 */
int Matrix::issquare()
{
    return m == n;
}

/**
 * @brief Matrix::left 求元素arr[x][y](x,y从0开始)的余子式;
 * @param x 矩阵
 * @param y 矩阵
 * @return 矩阵
 */
Matrix Matrix::left(int x,int y)
{ 
    Matrix leftMatrix;
    if((x>=m)||(y>=n))
    {
        cout<<"errer"<<endl;
        return leftMatrix;
    }

    leftMatrix.m = m - 1;
    leftMatrix.n = n - 1;
    int testx = 0;
    int testy = 0;
    for(int i=0;i<leftMatrix.m;i++)
    {
        testy = 0;
        for(int j=0;j<leftMatrix.n;j++)
        {
            if(i==x)
                testx = 1;
            if(j==y)
                testy = 1;
            if((!testx)&&(!testy))
                leftMatrix.arr[i][j] = this->arr[i][j];
            else if(testx&&(!testy))
                leftMatrix.arr[i][j] = this->arr[i+1][j];
            else if((!testx)&&testy)
                leftMatrix.arr[i][j] = this->arr[i][j+1];
            else
                leftMatrix.arr[i][j] = this->arr[i+1][j+1];
        }
    }
    return leftMatrix;
}



/**
 * @brief det 递归算法
 * @param x 矩阵
 * @return 行列式
 */
double det(Matrix x)
{
    if(!x.issquare())
    {
        cout<<"不是方阵!"<<endl;
        return 9.99;
    }
    if(x.m==0)
        return 0;
    else if(x.m==1)
        return x.arr[0][0];
    else if(x.m==2)
        return (x.arr[0][0]*x.arr[1][1] - x.arr[0][1]*x.arr[1][0]);
    else
    {
        double num = 0;
        int a = 1;
        for(int i=0;i<x.m;i++)
        {
            num = num + a*x.arr[0][i]*det(x.left(0,i));
            //! 按第0行展开
            a = -a;
        }
        return num;
    }
}


