/**
* @file matrix.h
* @brief 定义一个matrix类
*
* @author 讨论组
* @date  20141127
* @version 1.0
*/

#ifndef matrix_h
#define matrix_h

class Matrix
{
public:
    Matrix();
    Matrix(double );

    void set();/**< 对矩阵赋值;*/
    void show();/**< 在屏幕上显示矩阵;*/

    friend int homotype(Matrix &,Matrix &);/**< 是否同型;*/
    friend int multipliable(Matrix &,Matrix &);/**< 判断矩阵是否可相乘*/

    friend Matrix add(Matrix &,Matrix &);/**< 矩阵相加;*/
    friend Matrix subtract(Matrix &,Matrix &);/**< 矩阵相减*/
    friend Matrix multiply(Matrix &,Matrix &);/**< 矩阵相乘*/

    friend Matrix operator +(Matrix &,Matrix &);/**< 矩阵相加,对加号重载;*/
    friend Matrix operator -(Matrix &,Matrix &);/**< 矩阵相减,对减号重载;*/
    friend Matrix operator *(Matrix &,Matrix &);/**< 矩阵相乘,对乘号重载;*/

    int issquare(); /**< 判断是否为方阵;*/
    Matrix left(int x,int y);/**< 求元素arr[x][y](x,y从0开始)的余子式;*/
    friend double det(Matrix );/**< 求方阵的行列式;*/


private:
    int m;
    int n;
    double arr[8][8];
};

# endif
