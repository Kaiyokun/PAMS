#include <stdio.h>
#include "cmatrix.h"

int main()
{
    matrix A,B,C,D;
			
    set(&A);

    printf("显示矩阵A:n");
    show(&A);

    set(&B);

    printf("显示矩阵B:\n");
    show(&B);

    printf("显示矩阵C=A+B:\n");
    if(add(&A,&B,&C))
    	{ 
    		show(&C);
    		destroy(&C);
    	}
   
   printf("显示矩阵D=A-B:\n");
    if(subtract(&A,&B,&D))
    	{
    		show(&D);
    		destroy(&D);
    	}
      
  
    destroy(&A);
    destroy(&B);
    
    

    return 0;
}
