#include <stdio.h>
#include "cmatrix.h"

int main()
{
    matrix A,B;
			
    set(&A);

    printf("显示矩阵A:\n");
    show(&A);

    printf("矩阵A的行列式:\n");
    printf("%lf \n",det(&A));

    left(&A,0,0,&B);
    printf("显示矩阵A去掉a00所在行和列剩下元素组成的矩阵B:\n");
    show(&B);

    printf("矩阵B的行列式:\n");
    printf("%lf\n",det(&B));


    destroy(&A);
    destroy(&B);

    return 0;
}
