#include <stdio.h>
#include "cmatrix.h"

int main()
{
    matrix A,B,C,D,E;
			
    set(&A);

    printf("显示矩阵A:\n");
    show(&A);


    if(adjoint(&A,&B))
    {
        printf("显示矩阵A的伴随矩阵B:\n");
        show(&B);
        if(multiply(&A,&B,&D))
        {
            printf("显示矩阵D=A*B:\n");
            show(&D);
            destroy(&D);
        }

        destroy(&B);
    }

    if(inverse(&A,&C))
    {
        printf("显示矩阵A的逆矩阵C:\n");
        show(&C);
        if(multiply(&A,&C,&E))
        {
            printf("显示矩阵E=A*C:\n");
            show(&E);
            destroy(&E);
        }
        destroy(&C);
    }
  


    destroy(&A);


    return 0;
}
