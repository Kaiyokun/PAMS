#include <iostream>
#include "matrix.h"

int main()
{
    Matrix mat;
	mat.set();
	mat.show();
    std::cout << "这个矩阵的行列式:" <<std::endl;
    std::cout << det(mat) <<std::endl;
	return 0;
}
