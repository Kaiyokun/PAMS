#include <stdio.h>
#include "cmatrix.h"

int main()
{
    matrix A,B,C,D;
			
    set(&A);

    printf("显示矩阵A:\n");
    show(&A);

    set(&B);

    printf("显示矩阵B:\n");
    show(&B);


    if(multiply(&A, &B, &C))
    {
        printf("显示矩阵C=A*B:\n");
        show(&C);


        scalar_multiply(&C,3.0, &D);
        printf("显示矩阵D = 3*C:\n");
        show(&D);

        destroy(&C);
        destroy(&D);
    }
   

   
    destroy(&A);
    destroy(&B);


    return 0;
}
