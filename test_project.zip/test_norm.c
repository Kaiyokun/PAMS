#include <stdio.h>
#include "cmatrix.h"

int main()
{
    matrix A;
			
    set(&A);

    printf("显示矩阵A:\n");
    show(&A);

    
    printf("矩阵A的1范数等于%lf \n", one_norm(&A));
    printf("矩阵A的无穷范数等于%lf \n", infinite_norm(&A));
    printf("矩阵A的F范数等于%lf \n", f_norm(&A));
  
    destroy(&A);
 

    return 0;
}
