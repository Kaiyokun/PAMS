#include <stdio.h>
#include "cmatrix.h"

int main()
{
    matrix A;
			
    set(&A);
    printf("显示矩阵A:\n");
    show(&A);


    primary_transform_3(&A,0,1,3.0,ROW);
    printf("3.0*1行加到0行，显示矩阵A:\n");
    show(&A);

    primary_transform_3(&A,0,1,3.0,COLUMN);
    printf("3.0*1列加到0列, 显示矩阵A:\n");
    show(&A);

    primary_transform_1(&A,0,1,COLUMN);
    printf("0列和1列互换, 显示矩阵A:\n");
    show(&A);

    primary_transform_2(&A,0,3.0,COLUMN);
    printf("3.0*0列, 显示矩阵A:\n");
    show(&A);

    destroy(&A);

    return 0;
}
