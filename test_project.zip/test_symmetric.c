#include <stdio.h>
#include "cmatrix.h"

int main()
{
    matrix A,B;
			
    set(&A);
    printf("显示矩阵A:\n");
    show(&A);

    //转置矩阵
    transpose(&A,&B);
    printf("显示矩阵A的转置矩阵B:\n");
    show(&B);


    //转置矩阵
    if(is_symmetric(&A))
       printf("矩阵A为对称矩阵\n");
    else
       printf("矩阵A不是对称矩阵\n");

    //转置矩阵
    if(is_dissymmetric(&A))
       printf("矩阵A为反对称矩阵\n");
    else
       printf("矩阵A不是反对称矩阵\n");
  

    destroy(&A);
    destroy(&B);

    return 0;
}
