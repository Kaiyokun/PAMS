/*************************************************************************
	> File Name: cmatrix_test.c
	> Author: wangliupeng
	> Mail: wangliupeng@xtu.edu.cn 
	> Created Time: 2014年12月03日 星期三 15时42分53秒
 ************************************************************************/

#include<stdio.h>
#include "cmatrix.h"

int main()
{
    matrix A,B,C;

    initZero(&A,4,3);
    printf("显示4*3零矩阵A:\n");
    show(&A);

    unit(&B,4);
    printf("显示4*4单位矩阵B:\n");
    show(&B);


    set(&C);
    printf("显示矩阵C:\n");
    show(&C);
	
	destroy(&A);
    destroy(&B);
    destroy(&C);

	
	return 0;
}
